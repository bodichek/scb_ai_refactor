from ingest.models import FinancialStatement

def calculate_cashflow(user, year):
    """
    Vypočítá Cash Flow výkaz z FinancialStatement.data
    """
    fs = FinancialStatement.objects.filter(owner=user, year=year).first()
    if not fs or not fs.data:
        return None

    d = fs.data

    # Mapování názvů podle dat z OpenAI (velká písmena)
    revenue = float(d.get("Revenue", 0))
    cogs = float(d.get("COGS", 0))
    overheads = float(d.get("Overheads", 0))
    depreciation = float(d.get("Depreciation", 0))
    interest = float(d.get("Interest", 0))
    extraordinary = float(d.get("Extraordinary", 0))
    taxation = float(d.get("Tax", 0))
    dividends = float(d.get("Dividends", 0))
    fixed_assets = float(d.get("FixedAssets", 0))
    other_assets = float(d.get("OtherAssets", 0))
    capital_withdrawn = float(d.get("CapitalWithdrawn", 0))
    
    # Další data pro cash flow
    loans_received = float(d.get("LoansReceived", 0))
    loans_repaid = float(d.get("LoansRepaid", 0))
    asset_sales = float(d.get("AssetSales", 0))
    working_capital_change = float(d.get("WorkingCapitalChange", 0))
    cash_begin = float(d.get("CashBegin", 0))

    # --- Základní výpočty ---
    net_profit = revenue - cogs - overheads - depreciation - interest - taxation + extraordinary
    
    # --- Cash Flow z provozní činnosti ---
    operating_cf = net_profit + depreciation - working_capital_change - interest - taxation
    
    # --- Cash Flow z investiční činnosti ---
    capex = fixed_assets  # CapEx = nákup dlouhodobého majetku
    investing_cf = asset_sales - capex
    
    # --- Cash Flow z finanční činnosti ---
    financing_cf = loans_received - loans_repaid - dividends
    
    # --- Celková změna peněžních prostředků ---
    total_net_cash_flow = operating_cf + investing_cf + financing_cf
    cash_end = cash_begin + total_net_cash_flow

    return {
        # Pro template cashflow tabulku v index.html
        "net_profit": net_profit,
        "depreciation": depreciation,
        "working_capital_change": working_capital_change,
        "interest_paid": interest,
        "income_tax_paid": taxation,
        "operating_cf": operating_cf,
        
        "capex": capex,
        "asset_sales": asset_sales,
        "investing_cf": investing_cf,
        
        "loans_received": loans_received,
        "loans_repaid": loans_repaid,
        "dividends_paid": dividends,
        "financing_cf": financing_cf,
        
        "net_cash_flow": total_net_cash_flow,
        "cash_begin": cash_begin,
        "cash_end": cash_end,
        
        # Pro původní template cashflow.html (zachováváme kompatibilitu)
        "revenue": revenue,
        "cogs": cogs,
        "overheads": overheads,
        "interest": interest,
        "extraordinary": extraordinary,
        "taxation": taxation,
        "dividends": dividends,
        "fixed_assets": fixed_assets,
        "other_assets": other_assets,
        "capital_withdrawn": capital_withdrawn,
        "gross_margin": revenue - cogs,
        "operating_cash_profit": revenue - cogs - overheads,
        "retained_profit": net_profit,
        "gross_cash_profit": revenue * 0.93 - cogs * 0.98,
        "operating_cash_flow": operating_cf,
        "variance": {
            "gross": (revenue - cogs) - (revenue * 0.93 - cogs * 0.98),
            "operating": (revenue - cogs - overheads) - operating_cf,
            "net": net_profit - total_net_cash_flow,
        },
    }
